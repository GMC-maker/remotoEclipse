package b1_herencia;


public class E2_Hora12_Main {
	
	public static void main(String[] args) {
		
		E2_Hora12 hh2 = new E2_Hora12(12,10,E2_Hora12.Meridiano.AM);
		
		System.out.println(hh2);
		
		hh2.setHora(24);
		hh2.setMinutos(0);
		
		System.out.println(hh2);
	}

}
