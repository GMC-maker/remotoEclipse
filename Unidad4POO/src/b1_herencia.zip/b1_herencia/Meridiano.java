package b1_herencia;

public enum Meridiano {
AM,PM
}
