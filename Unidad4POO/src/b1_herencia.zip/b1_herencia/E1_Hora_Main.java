package b1_herencia;

import java.util.Scanner;

public class E1_Hora_Main {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int dato;
		
		E1_Hora hh = new E1_Hora(11,30);
		System.out.println(hh);
		
		//incrementamos 1 minuto
		hh.inc();//invocamos el metodo para aumentar en 1 minuto
		System.out.println(hh);

		
		System.out.println(" SET HORA: ");
		dato = sc.nextInt();
		hh.setHora(dato); // cambiamos la hora.
		
		System.out.println(" SET MINUTOS: ");
		dato = sc.nextInt();
		hh.setMinutos(dato); // cambiamos minutos 
		System.out.println(hh);
		
	}

}
