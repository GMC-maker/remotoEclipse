package b1_herencia;

public class E2_Hora12 extends E1_Hora {

	// atributos

	public enum Meridiano {AM,PM}
	protected Meridiano mer;

	// constructors
	
	public E2_Hora12(int hora, int minuto, Meridiano mer) {
		// hora de 0 a 12
		super(hora, minuto); // el padre permite horas de 0 a 23
		setHora(hora); // agregamos nuestro m�todo setHORA
		this.mer = mer;
	}

	// methods

	@Override
	public void setHora(int hora) {
			if (hora >= 1 && hora <=12) {
		    this.hora = hora;
		} else if(hora > 12) {
			hora -=12;
			this.hora = hora;
			cambiarMeridiano();
		}
	}

	@Override
	public void inc() {
		super.inc();
		if (hora == 13) {
			hora = 1;
			cambiarMeridiano();
		}
	}

	public void cambiarMeridiano() {
		if (this.mer == Meridiano.AM) {
			this.mer = Meridiano.PM;
		} else {
			this.mer = Meridiano.AM;
		}

	}

	@Override
	public String toString() {
		
		return " Hora12: " + super.toString()+ mer;
	}
	
	

}